import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:video_player_demo/global.dart';
import 'package:video_player_demo/main.dart';

class HeroPlayer extends StatelessWidget {
  final PlayerItem controller;

  const HeroPlayer({required this.controller, super.key});

  @override
  Widget build(BuildContext context) {
    return Hero(
      tag: controller.url,
      child: Container(
        height: MediaQuery.of(context).size.height,
        color: Colors.black,
        child: Center(
          child: ValueListenableBuilder(
            valueListenable: controller.controller,
            builder: (_, value, child) {
              if (value.isInitialized) {
                return ValueListenableBuilder(
                  valueListenable: currentController,
                  builder: (_, current, child) {
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      if (current!.url == controller.url) {
                        controller.controller.play();
                      } else {
                        controller.controller.pause();
                      }
                    });
                    return child!;
                  },
                  child: AspectRatio(
                    aspectRatio: value.aspectRatio,
                    child: VideoPlayer(controller.controller),
                  ),
                );
              } else {
                return Center(
                  child: CircularProgressIndicator(), // Displays the loading spinner
                );
              }
            },
          ),
        ),
      ),
    );
  }
}
