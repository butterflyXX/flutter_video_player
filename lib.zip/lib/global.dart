import 'package:flutter/material.dart';
import 'package:video_player_demo/main.dart';

final currentController = ValueNotifier<PlayerItem?>(null);